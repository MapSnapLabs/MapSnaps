# MapSnaps MVP
Basic mobile MVP for MapSnaps app.