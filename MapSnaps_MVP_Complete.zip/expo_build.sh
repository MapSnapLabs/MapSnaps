#!/bin/bash
echo "Building with EAS..."
eas build --platform android