#!/bin/bash
git add .
git commit -m "Update MVP with complete screens and config"
git push